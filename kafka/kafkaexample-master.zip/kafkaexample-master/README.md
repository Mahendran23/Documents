# kafkaexample
Apache Kafka maven Example. It has examples on java implementation of Kafka producer and consumer.This project alo demonstrates about 
creating partitioned topic and consuming messages from those partition by a consumer group.
The article was posted with complete explanation on - [Apache Kafka Java Example with Maven](www.devglan.com/corejava/apache-kafka-java-example)

